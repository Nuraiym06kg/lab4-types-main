

import type { StudentResponse } from "./dto";

export function isRecord(
  x: unknown
): x is Record<string, unknown> {
  return (
    typeof x === "object" &&
    x !== null &&
    !Array.isArray(x)
  );
}

export function isStudentResponse(
  x: unknown
): x is StudentResponse {
  if (!isRecord(x)) {
    return false;
  }

  const validStatus =
    x.status === "ACTIVE" ||
    x.status === "INACTIVE" ||
    x.status === "GRADUATED";

  return (
    typeof x.id === "number" &&
    Number.isFinite(x.id) &&
    typeof x.firstName === "string" &&
    typeof x.lastName === "string" &&
    typeof x.email === "string" &&
    (
      x.phone === undefined ||
      typeof x.phone === "string"
    ) &&
    validStatus &&
    typeof x.createdAt === "string"
  );
}

