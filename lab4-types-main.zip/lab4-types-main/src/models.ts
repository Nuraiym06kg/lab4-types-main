
export type UserRole = "ADMIN" | "TEACHER" | "STUDENT";

export type StudentStatus = "ACTIVE" | "INACTIVE" | "GRADUATED";

export type CourseStatus = "DRAFT" | "PUBLISHED" | "ARCHIVED";

export type EnrollmentStatus = "ENROLLED" | "COMPLETED" | "CANCELLED";

export interface User {
  id: number;
  email: string;
  passwordHash: string;
  role: UserRole;
  createdAt: string;
}

export interface Student {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  status: StudentStatus;
  readonly createdAt: string;
}

export interface Course {
  id: number;
  title: string;
  description: string;
  priceKgs: number;
  teacherId: number;
  status: CourseStatus;
  readonly createdAt: string;
}

export interface Enrollment {
  id: number;
  studentId: number;
  courseId: number;
  enrolledAt: string;
  status: EnrollmentStatus;
}
