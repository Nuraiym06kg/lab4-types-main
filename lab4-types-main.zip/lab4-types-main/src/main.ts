
import type { Student, Course, Enrollment, User } from "./models";
import {
  toStudentResponse,
  toCourseResponse,
  toEnrollmentResponse,
  toUserResponse,
  paginate
} from "./mappers";
import { parseStudentResponse } from "./api";

const students: Student[] = [
  {
    id: 1,
    firstName: "Aigerim",
    lastName: "Asanova",
    email: "aigerim@example.com",
    phone: "+996 555 123 456",
    status: "ACTIVE",
    createdAt: "2026-09-01T09:00:00Z"
  },
  {
    id: 2,
    firstName: "Bakyt",
    lastName: "Toktogulov",
    email: "bakyt@example.com",
    status: "ACTIVE",
    createdAt: "2026-09-02T09:00:00Z"
  },
  {
    id: 3,
    firstName: "Nurzat",
    lastName: "Kadyrova",
    email: "nurzat@example.com",
    status: "GRADUATED",
    createdAt: "2026-09-03T09:00:00Z"
  }
];

const courses: Course[] = [
  {
    id: 1,
    title: "TypeScript",
    description: "Основы TypeScript",
    priceKgs: 3000,
    teacherId: 10,
    status: "PUBLISHED",
    createdAt: "2026-09-01T09:00:00Z"
  },
  {
    id: 2,
    title: "JavaScript",
    description: "Основы JavaScript",
    priceKgs: 2500,
    teacherId: 10,
    status: "PUBLISHED",
    createdAt: "2026-09-02T09:00:00Z"
  },
  {
    id: 3,
    title: "Python",
    description: "Основы Python",
    priceKgs: 3500,
    teacherId: 11,
    status: "DRAFT",
    createdAt: "2026-09-03T09:00:00Z"
  }
];

const enrollments: Enrollment[] = [
  {
    id: 1,
    studentId: 1,
    courseId: 1,
    enrolledAt: "2026-09-04T09:00:00Z",
    status: "ENROLLED"
  },
  {
    id: 2,
    studentId: 2,
    courseId: 2,
    enrolledAt: "2026-09-05T09:00:00Z",
    status: "COMPLETED"
  },
  {
    id: 3,
    studentId: 3,
    courseId: 3,
    enrolledAt: "2026-09-06T09:00:00Z",
    status: "CANCELLED"
  }
];

const user: User = {
  id: 10,
  email: "teacher@example.com",
  passwordHash: "demo-hash-not-a-real-password",
  role: "TEACHER",
  createdAt: "2026-09-01T09:00:00Z"
};

console.log("=== Студенты ===");
console.log(students.map(toStudentResponse));

console.log("=== Курсы ===");
console.log(courses.map(toCourseResponse));

console.log("=== Записи на курсы ===");
console.log(enrollments.map(toEnrollmentResponse));

console.log("=== Пользователь без passwordHash ===");
console.log(toUserResponse(user));

console.log("=== Первая страница студентов ===");
console.log(paginate(students, 1, 2));

console.log("=== Проверка JSON ===");

const testJson = [
  JSON.stringify(students[0]),
  JSON.stringify({ ...students[0], id: "не число" }),
  JSON.stringify({
    firstName: "Aigerim",
    lastName: "Asanova"
  }),
  JSON.stringify({ ...students[0], status: "UNKNOWN" }),
  "{invalid json"
];

for (const json of testJson) {
  console.log(parseStudentResponse(json));
}
