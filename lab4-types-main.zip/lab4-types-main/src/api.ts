
import type { Result, StudentResponse } from "./dto";
import { isStudentResponse } from "./guards";

export function parseStudentResponse(
  json: string
): Result<StudentResponse> {
  let data: unknown;

  try {
    data = JSON.parse(json);
  } catch {
    return {
      ok: false,
      status: 400,
      message: "Некорректный JSON"
    };
  }

  if (!isStudentResponse(data)) {
    return {
      ok: false,
      status: 422,
      message: "Данные не соответствуют StudentResponse"
    };
  }

  return { ok: true, data };
}
