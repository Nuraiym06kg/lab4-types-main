
import type {
  User,
  Student,
  Course,
  Enrollment
} from "./models";

import type {
  UserResponse,
  StudentResponse,
  CourseResponse,
  EnrollmentResponse,
  Paginated
} from "./dto";

export function toUserResponse(user: User): UserResponse {
  return {
    id: user.id,
    email: user.email,
    role: user.role,
    createdAt: user.createdAt
  };
}

export function toStudentResponse(
  student: Student
): StudentResponse {
  return {
    id: student.id,
    firstName: student.firstName,
    lastName: student.lastName,
    email: student.email,
    ...(student.phone !== undefined
      ? { phone: student.phone }
      : {}),
    status: student.status,
    createdAt: student.createdAt
  };
}

export function toCourseResponse(
  course: Course
): CourseResponse {
  return {
    id: course.id,
    title: course.title,
    description: course.description,
    priceKgs: course.priceKgs,
    teacherId: course.teacherId,
    status: course.status,
    createdAt: course.createdAt
  };
}

export function toEnrollmentResponse(
  enrollment: Enrollment
): EnrollmentResponse {
  return {
    id: enrollment.id,
    studentId: enrollment.studentId,
    courseId: enrollment.courseId,
    enrolledAt: enrollment.enrolledAt,
    status: enrollment.status
  };
}

export function paginate<T>(
  items: T[],
  page: number,
  limit: number
): Paginated<T> {
  const safePage = Math.max(1, Math.floor(page));
  const safeLimit = Math.max(1, Math.floor(limit));
  const start = (safePage - 1) * safeLimit;

  return {
    items: items.slice(start, start + safeLimit),
    total: items.length,
    page: safePage,
    limit: safeLimit
  };
}
