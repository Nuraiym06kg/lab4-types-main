
import type {
  User,
  Student,
  Course,
  Enrollment
} from "./models";

export type CreateStudentDto = Omit<
  Student,
  "id" | "createdAt"
>;

export type UpdateStudentDto = Partial<CreateStudentDto>;

export type StudentResponse = Student;

export type CreateCourseDto = Omit<
  Course,
  "id" | "createdAt"
>;

export type UpdateCourseDto = Partial<CreateCourseDto>;

export type CourseResponse = Course;

export type CreateEnrollmentDto = Pick<
  Enrollment,
  "studentId" | "courseId"
>;

export type EnrollmentResponse = Enrollment;

export type UserResponse = Omit<User, "passwordHash">;

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
}

export type Result<T> =
  | { ok: true; data: T }
  | { ok: false; status: number; message: string };
