
# Журнал ошибок компилятора и работы с ИИ

## 1. Ошибка несовместимости типов

**Код:**
```typescript
const price: number = "3000";
```

**Причина:** строка присвоена переменной типа `number`.

**Исправление:**
```typescript
const price: number = 3000;
```

## 2. Ошибка отсутствующего свойства

**Код:**
```typescript
const student = { firstName: "Aigerim" };
console.log(student.lastName);
```

**Причина:** свойство `lastName` отсутствует в типе объекта.

**Исправление:**
```typescript
const student = {
  firstName: "Aigerim",
  lastName: "Asanova"
};
```

## 3. Возможное значение undefined

**Код:**
```typescript
const student = students.find(s => s.id === 99);
console.log(student.firstName);
```

**Причина:** метод `find` может вернуть `undefined`.

**Исправление:**
```typescript
const student = students.find(s => s.id === 99);

if (student) {
  console.log(student.firstName);
}
```

## 4. Изменение readonly-свойства

**Код:**
```typescript
student.createdAt = "2026-10-01T09:00:00Z";
```

**Причина:** свойство `createdAt` доступно только для чтения.

**Исправление:** задать дату при создании объекта или создать новый объект.

## 5. Недопустимое значение статуса

**Код:**
```typescript
const status: StudentStatus = "BLOCKED";
```

**Причина:** значение `BLOCKED` не входит в объединение `StudentStatus`.

**Исправление:**
```typescript
const status: StudentStatus = "ACTIVE";
```

## 6. Работа с ИИ: проверка DTO

**Запрос:** проверить DTO и исключить передачу секретных полей клиенту.

**Результат:** для `UserResponse` применён тип `Omit<User, "passwordHash">`.

**Проверка:** в выводе программы отсутствует `passwordHash`.

## 7. Работа с ИИ: проверка JSON

**Запрос:** реализовать безопасную проверку JSON без доверия входным данным.

**Результат:** применены `unknown`, `try/catch` и функция `isStudentResponse`.

**Проверка:** `npm run check` и `npm run dev` завершились успешно.
